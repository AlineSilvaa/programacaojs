# TextWrap

Nesse exercício você deverá criar uma aplicação Angular (2 ou 4) que possuí em sua página inicial um textarea e um textfield e um botão. Ao apertar o botão, um método do serviço injetável que você irá criar deverá ser chamado e quebrar o texto no número específico de caracteres, leia o textwrap.interface.ts para mais detalhes.

## Dicas

1. Instale o Angular CLI (https://cli.angular.io/)

2. Crie um novo projeto com `ng new textWrap`

3. Crie um repositório no GitHub para esse exercício

4. Copie os conteúdos dessa pasta (esse arquivo incluso) para as pastas equivalentes no seu repositório

5. Utilize o `ng serve` para desenvolver seu ambiente local, você poderá acessá-lo em [http://localhost:4200/](http://localhost:4200/)

6. Crie o formulário com o botão de submissão e o elemento onde irá exibir o resultado do teu TextWrapService

7. Implemente o textwrap service (use `implements TextWrapInterface`)

8. **BONUS** escreva testes unitários para o TextWrapService

PS: Não se esqueça de nos enviar o endereço do seu repositório, e fazer commits atômicos.