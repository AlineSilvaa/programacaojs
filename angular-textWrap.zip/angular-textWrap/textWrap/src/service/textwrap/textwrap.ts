import { TextWrapInterface } from './textwrap.interface';

// Seu código vai aqui :)