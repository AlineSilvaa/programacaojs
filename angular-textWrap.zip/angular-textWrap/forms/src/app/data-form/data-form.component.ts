import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-date-form',
  templateUrl: './data-form.component.html',
  styleUrls: ['./data-form.component.css']
})
export class DataFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
